# envrun

`envrun` stores and links project dotenv sets through 1Password CLI. One project
name identifies one tagged Secure Note item, and every environment key is a
concealed field on that item. The default link contains `op://` references;
plaintext is written only when `--download` is explicit.

This repository currently contains a private, workstation-local v0.1. It is not
a production secret delivery system, CI integration, team policy engine, or OS
sandbox. Read [Security model](docs/SECURITY.md) before using it with sensitive
credentials.

## Simple workflow

After installation and one-time account setup, import an existing dotenv file:

```sh
envrun store .env ruth
```

Here, `ENV_FILE` is the dotenv file to read or write, and `PROJECT` is a name
you choose for the stored environment set. In this example, `.env` is the
environment file and `ruth` is the project name. Use the same project name with
`store` and `link`; it is a label for the 1Password item, not a path or external
project ID.

The command reads the local file, creates a 1Password item named `ruth`, and
sends its values to `op item create` as a JSON template over standard input.
Values are never placed in command arguments or printed. The original `.env`
is left in place; remove it only after verifying the 1Password item.

On the same or another workstation, create a reference-only dotenv file:

```sh
envrun link .env ruth
```

The resulting file looks like this and is written atomically with mode `0600`:

```dotenv
DATABASE_URL=op://VAULT_ID/ITEM_ID/envrun/DATABASE_URL
OPENAI_API_KEY=op://VAULT_ID/ITEM_ID/envrun/OPENAI_API_KEY
```

Use it without downloading the values:

```sh
op run --env-file=.env -- npm run dev
```

If a tool genuinely requires plaintext, request that behavior explicitly:

```sh
envrun link .env ruth --download
```

This replaces the requested file atomically with a conventional plaintext
dotenv file at mode `0600`. It is then your responsibility to keep that file
out of version control and remove it when it is no longer needed.

To replace the complete environment set already stored for a project:

```sh
envrun store .env ruth --replace
```

Existing stored sets are never replaced without `--replace`. Use
`--vault VAULT` with either command to select a 1Password vault by name or ID,
for example `--vault Development`. If omitted, envrun uses the configured
account's default vault. An explicit vault is also useful when the same project
name exists in more than one vault.

## Advanced broker workflow

`envrun` separates four concerns:

1. A **1Password item field** owns the value.
2. A global **slot** gives its static `op://` reference a stable logical name.
3. A global **bundle** maps environment variable names to reusable slots.
4. A project **manifest** selects bundles, project-specific bindings, explicit
   collision overrides, and narrowly selected ambient passthrough variables.

Before a command can run, `envrun plan` shows the effective access set and
`envrun approve` requires an exact phrase from an interactive terminal. A run
never auto-approves or prompts for approval.

The runtime path is:

```text
.dev-env.toml + central slots/bundles
                 |
                 v
          plan and approval
                 |
                 v
       references-only temporary file
                 |
                 v
              op run
                 |
        resolved process environment
                 |
                 v
      envrun filter + process.execve
                 |
                 v
       requested target process tree
```

In this advanced execution path, the outer `envrun` controller resolves
managed-reference metadata, not managed secret values. It necessarily reads any
explicitly authorized passthrough value already present in its ambient
environment. Managed values first enter an `envrun` trampoline's process
environment after `op run` resolves them. The trampoline filters the environment
again and replaces itself with the target executable. This path does not write
resolved values to a file. The separate `store` and `link --download` commands
intentionally handle plaintext as described above.

## Scope and prerequisites

Version 1 is intentionally limited to interactive local development:

- Node.js 24 is required. The clean target handoff uses `process.execve`.
- npm 11 is the repository package-manager convention.
- 1Password CLI 2.x and the 1Password desktop app must be installed.
- The desktop app must be signed in and its CLI integration must be enabled.
- Authentication must use desktop app integration. Service-account, Connect,
  and `OP_SESSION_*` token environments are refused.
- Context names beginning with `prod` are refused. Do not use this tool for
  production, deployment, CI, shared hosts, or unattended execution.
- The current implementation and test suite target local Linux and macOS
  workstations. Configuration updates use Linux `/usr/bin/flock` or macOS
  `/usr/bin/lockf`. Windows and other Unix systems are not supported v1 runtimes.

In the 1Password desktop app, enable **Settings > Developer > Integrate with
1Password CLI**. See 1Password's documentation for [desktop app
integration](https://www.1password.dev/cli/app-integration) and [secret
references](https://www.1password.dev/cli/secret-references).

Confirm the local prerequisites before installing:

```sh
node --version
op --version
op vault list
command -v ssh-keygen
```

The final command should authenticate through the desktop app. Choose the
account `envrun` will pin during setup; a pinned selector is required before
approval or execution, even on a single-account workstation.

## Install a verified release

The recommended installer downloads an immutable, versioned Linux or macOS archive from
the public `envrun-releases` repository. It verifies the publisher's Ed25519
signature, the archive checksum, and the archive's internal file manifest before
installing a small launcher in `~/.local/bin`:

```sh
curl -fsSL https://github.com/michaelshimeles/envrun-releases/releases/latest/download/envrun-install.sh | sh
```

The destination machine needs Linux or macOS, Node.js 24, and OpenSSH's `ssh-keygen`, but
does not need npm or a source checkout. Release contents live under
`$XDG_DATA_HOME/envrun/releases/` (default:
`~/.local/share/envrun/releases/`). Each directory name includes the package
version and archive digest. Re-running the command installs the latest release
and atomically repoints only a recognized envrun release wrapper; it never
overwrites an unrelated command.

To inspect the installer before running it:

```sh
curl -fsSLo envrun-install https://github.com/michaelshimeles/envrun-releases/releases/latest/download/envrun-install.sh
less envrun-install
sh envrun-install
```

Pin a specific release when reproducibility matters:

```sh
curl -fsSL https://github.com/michaelshimeles/envrun-releases/releases/download/v0.1.3/envrun-install.sh | \
  sh -s -- --version 0.1.3
```

The release-signing key fingerprint is
`SHA256:zlZge1Zqmjg8ojDlhyLhinBU8o20xpjlb2zpbrAhDJ8`. The public key is stored
in `release-signing-key.pub` and embedded in the installer. GitHub release
immutability locks every published asset and its tag; a separate signature
binds the archive, installer, public key, and SBOM even before publication.
Each release also includes an SPDX 2.3 software bill of materials
and GitHub's automatically generated immutable-release attestation.

Verify the launcher is available before continuing:

```sh
command -v envrun
envrun --version
```

## Install from this checkout

For development, install from the private source checkout instead. This path
requires Node.js 24 and npm 11. From the repository root:

```sh
npm ci
npm run check
npm run install:local
```

The installer builds `dist/` and writes a small executable wrapper at
`~/.local/bin/envrun`. Verify that directory is on `PATH`:

```sh
command -v envrun
envrun --version
```

For another absolute bin directory:

```sh
npm run install:local -- --bin-dir /absolute/path/to/bin
```

The local wrapper records the absolute Node 24 executable path used during
installation and imports `dist/cli.js` from this checkout. A later
`npm run build` is picked up without reinstalling. Re-run `npm run install:local`
only if the checkout path or Node executable path changes. Before moving the
repository, uninstall the old wrapper as described below, then install a new
wrapper from the new location; the installer intentionally refuses to overwrite
a wrapper owned by a different checkout.

The installed launcher, Node runtime, this checkout's `dist/` output, and its
runtime dependencies are part of the trusted broker. They remain mutable, and
an `envrun` source, build, or dependency change does **not** make project
approvals stale. The installer verifies ownership and refuses world-writable
paths; group-writable paths are accepted only when owned by your primary group.
Keep that primary group private. Review updates, install from the lockfile with
`npm ci`, rebuild, and run `npm run check` before using the updated broker.

## First-time setup

Run setup once. It discovers `op` from `PATH`, resolves it to an absolute
executable, and creates private configuration and approval-state directories.
List the signed-in accounts, then pin the intended selector:

```sh
op account list
envrun setup --account my.1password.com
```

Setup without `--account` is allowed for preliminary planning and diagnostics,
but `envrun approve` and `envrun run` refuse to proceed until an account is
pinned:

```sh
envrun setup
envrun setup --update --account my.1password.com
```

An explicit CLI path can be supplied on first setup:

```sh
envrun setup --op-path /usr/bin/op --account my.1password.com
```

Existing settings are not silently overwritten. Change them explicitly:

```sh
envrun setup --update --account another.1password.com
envrun setup --update --op-path /absolute/path/to/op
envrun setup --update --clear-account
```

Changing the configured account selector or trusted `op` executable makes
existing project approvals stale. Clearing the account selector also blocks new
approvals and runs until another selector is pinned.

By default, state is stored under the XDG paths:

```text
$XDG_CONFIG_HOME/envrun/          (default: ~/.config/envrun/)
  settings.toml
  slots.toml
  bundles/<hierarchical-id>.toml

$XDG_STATE_HOME/envrun/           (default: ~/.local/state/envrun/)
  approvals/<digest>.json
```

The `envrun` directories must be owned by the current user and have mode
`0700`. Central
files, approval files, and configuration lock files must have mode `0600`.
Symlinks are refused. Central configuration contains 1Password references and
account metadata, not secret values. Treat those references as private metadata
even though they are not passwords or tokens.

Setup, slot, and bundle mutations use Linux's `/usr/bin/flock` or macOS's
`/usr/bin/lockf` over private lock files, then write state atomically. Competing
updates wait for the kernel advisory lock, and a crashed lock holder releases it
automatically. The lock files themselves normally remain in the configuration directory.

## Put values in 1Password manually for the advanced workflow

The simple `envrun store` workflow creates and updates a dedicated project item.
For advanced slots and bundles, create or choose 1Password item fields manually.
Enter those actual values only in 1Password. Neither workflow puts a value on an
`envrun` or `op` command line. Explicit passthrough values remain sourced from
the caller's environment and may themselves be sensitive; authorize them only
when they genuinely cannot be managed as slots.

Copy a static secret reference for each field. Version 1 accepts this shape:

```text
op://VAULT/ITEM/FIELD
op://VAULT/ITEM/SECTION/FIELD
```

References containing interpolation such as `op://$APP_ENV/...` are rejected.
Prefer durable item and field references and keep each logical slot's purpose
narrow.

If migrating an existing plaintext `.env`, first move each value into the
correct 1Password field, configure and test `envrun`, and only then remove the
old file and any copies or backups according to your normal secure deletion and
credential-rotation procedure.

## Register global slots

A slot maps a logical, reusable ID to exactly one static 1Password reference.
The following examples contain references only:

```sh
envrun slot set providers/openai/default \
  'op://Developer/OpenAI/api-key'

envrun slot set projects/ruth/database \
  'op://Developer/Ruth/database-url'

envrun slot set projects/ezekiel/database \
  'op://Developer/Ezekiel/database-url'
```

Logical IDs are lowercase slash-delimited paths such as
`providers/openai/default`. Each segment must begin with a lowercase letter and
may then contain lowercase letters, digits, `_`, or `-`. Environment names use
the conventional `NAME` form and may not use an `envrun`-reserved execution or
authentication name.

Inspect registered IDs and reference digests:

```sh
envrun slot list
```

`slot list` intentionally does not print full `op://` references. Rebinding a
slot requires an explicit flag and invalidates every approval whose effective
access set used the old reference:

```sh
envrun slot set projects/ruth/database \
  'op://Developer/Ruth/database-url-v2' --replace
```

Rotating the value inside the same 1Password field does not change its
reference and does not require reapproval.

Remove an unused slot explicitly:

```sh
envrun slot remove projects/ruth/database --yes
```

Removal does not rewrite bundles or project manifests. A remaining reference to
the removed slot causes planning to fail closed.

## Create reusable bundles

A bundle maps one or more environment names to logical slots. For example, one
OpenAI credential can be reused by many local projects without repeating its
1Password reference:

```sh
envrun bundle set providers/openai \
  OPENAI_API_KEY=slot://providers/openai/default \
  --description 'Shared local OpenAI credential'
```

Inspect bundles:

```sh
envrun bundle list
envrun bundle show providers/openai
```

`bundle set --replace` replaces the complete bundle definition; include every
export that should remain:

```sh
envrun bundle set providers/openai \
  OPENAI_API_KEY=slot://providers/openai/default \
  OPENAI_ORG_ID=slot://providers/openai/org \
  --description 'Shared local OpenAI credentials' \
  --replace
```

Remove a bundle with:

```sh
envrun bundle remove providers/openai --yes
```

As with slots, projects that still select a removed bundle fail during
planning.

## Initialize a project manifest

From a project root, initialize from an `.env.example`-style schema:

```sh
envrun init --from .env.example --project ruth --target app
```

The schema and target working directory must already exist, must be inside the
project root, and may not traverse symlinks. Running `init` again with another
`--target` adds a target to the existing manifest rather than replacing it.

The generated `.dev-env.toml` is safe to commit in the narrow sense that it
contains no secret values or full `op://` references. It does contain project
metadata, paths, environment names, and logical `slot://` names, and changes can
request new access. A complete target looks like this:

```toml
version = 1
project = "ruth"
default_target = "app"
default_context = "local"

[targets.app]
schema = ".env.example"
cwd = "."
allow_unlisted = []
passthrough = []
optional_passthrough = []

[targets.app.contexts.local]
bundles = ["providers/openai"]

[targets.app.contexts.local.bindings]
DATABASE_URL = "slot://projects/ruth/database"

[targets.app.contexts.local.overrides]
```

### Manifest semantics

- `project`: a local project identifier. The canonical project root is the
  directory that contains the manifest.

- `default_target`: the target selected when `--target` is omitted. Each target
  has a separate schema, working directory, access plan, and approval.

- `default_context`: must be `local` in v1. Additional explicitly selected
  non-production contexts can be defined under a target, but any context
  beginning with `prod` is refused.

- `schema`: a relative path to an `.env.example`-style file. It is an
  **authorization allowlist**, not a required-variable declaration. Lines may be
  blank, comments, or assignments such as `NAME=` and `export NAME=`. Values on
  the right-hand side are not loaded. Keep them empty or demonstrably synthetic;
  `envrun` ignores rather than sanitizes plaintext accidentally placed there.

- `cwd`: the target process working directory, relative to the project root.

- `allow_unlisted`: additional environment names that a binding or passthrough
  declaration may authorize even though they are absent from the schema. Keep
  this list small.

- `passthrough`: ambient names that must exist when running the target and are
  explicitly inherited. A missing required passthrough makes `doctor` and the
  run fail. A name cannot be both managed by a slot and passed through.

- `optional_passthrough`: ambient names inherited only when currently set. The
  declaration is still part of the approved access set.

- `bundles`: global bundle IDs selected for the context. Array order never
  grants precedence or breaks a tie; every multi-source collision needs an
  explicit `overrides` winner.

- `bindings`: project-specific environment-name-to-slot mappings.

- `overrides`: an exact existing source selector when bundles or the project
  binding provide the same environment name. Bundle sources use `bundle:ID`;
  the current project's binding source uses
  `project:PROJECT/TARGET/CONTEXT`. An override is not a `slot://` mapping and
  does not add a candidate. Collisions fail even when the candidates ultimately
  reference the same 1Password field. A missing override, a source that is not
  one of the candidates, or an override where there is no collision fails
  closed.

For example, if both `providers/openai` and `providers/alternate` export
`OPENAI_API_KEY`, select the first bundle explicitly:

```toml
[targets.app.contexts.local.overrides]
OPENAI_API_KEY = "bundle:providers/openai"
```

To select the project binding instead, the exact selector in Ruth's `app/local`
context is `project:ruth/app/local`. Bundle array order never chooses the
winner.

### Local context overlays

The target-level schema, `cwd`, and passthrough declarations apply to every
context under that target. Each context independently declares its bundles,
bindings, and overrides; contexts do not implicitly inherit those three tables
from `local`. For example, a local test context can select another database slot:

```toml
[targets.app.contexts.test]
bundles = ["providers/openai"]

[targets.app.contexts.test.bindings]
DATABASE_URL = "slot://projects/ruth/test-database"

[targets.app.contexts.test.overrides]
```

Select it explicitly with `--context test`. It receives a separate approval
from `local`. This facility is only for local non-production variants; every
`prod*` context remains prohibited.

The effective runtime contract is the set of managed bundle/binding winners,
required passthrough names, and currently present optional passthrough names.
Merely listing a name in `.env.example` does not inject it. For example:

```dotenv
OPENAI_API_KEY=
DATABASE_URL=
UNBOUND_EXAMPLE=
```

If only the first two names have managed bindings, `UNBOUND_EXAMPLE` is absent
from the target environment. This makes the schema a ceiling on access, not a
request to inherit every matching variable from the caller.

Common variables such as `SSH_AUTH_SOCK`, proxy settings, certificate paths,
and tool-specific configuration are not inherited automatically. Add them to
the schema or `allow_unlisted`, then choose required or optional passthrough
semantics deliberately.

## Illustrative shared-provider, isolated-database pattern

This synthetic example demonstrates composition; it is not the shipped Ruth or
Ezekiel setup. Their current primary model credential is `AI_GATEWAY_API_KEY`
or platform OIDC, and their browser-auth requirements are project-specific.
Use each repository's `.dev-env.toml` and `.env.example` as the operative
contract. The illustrative slots and bundle above implement this access model:

| Project | `OPENAI_API_KEY` | `DATABASE_URL` |
| --- | --- | --- |
| Ruth | `providers/openai/default` | `projects/ruth/database` |
| Ezekiel | `providers/openai/default` | `projects/ezekiel/database` |

For Ezekiel, use the same schema and provider bundle but its own binding:

```toml
version = 1
project = "ezekiel"
default_target = "app"
default_context = "local"

[targets.app]
schema = ".env.example"
cwd = "."
allow_unlisted = []
passthrough = []
optional_passthrough = []

[targets.app.contexts.local]
bundles = ["providers/openai"]

[targets.app.contexts.local.bindings]
DATABASE_URL = "slot://projects/ezekiel/database"

[targets.app.contexts.local.overrides]
```

Ruth and Ezekiel resolve the same OpenAI field but different database fields.
Their approvals are independent because approvals are bound to the canonical
project directory, target, context, and effective access set. Ruth cannot
receive Ezekiel's database through this configuration, and an accidental
database-name collision fails unless the project declares an explicit
override.

The `projects/ruth/...` and `projects/ezekiel/...` prefixes are naming
conventions, not ACLs. A changed Ruth manifest can request Ezekiel's slot, but
the new logical source and reference digest appear in its plan and require
explicit reapproval. Do not approve that request unless the cross-project access
is intentional.

This is environment-injection isolation, not OS isolation. Once approved code
runs, it can use every value supplied to its process tree. See
[Security model](docs/SECURITY.md).

## Plan and approve access

From a project directory or any nested directory beneath it:

```sh
envrun plan
envrun plan --json
```

Select another target or context explicitly when needed:

```sh
envrun plan --target worker --context local
```

The text plan shows logical slot IDs, sources, short reference digests,
passthrough declarations, target paths, and approval status. The JSON plan also
contains the configured `op` path, configured account selector (or `null`), and
a short executable identity digest. Neither form prints full `op://` references
or values.

Approval status is one of:

- `missing`: no approval exists for this project/target/context.
- `valid`: the current effective access set matches the stored approval.
- `stale`: a security-relevant input changed and must be reviewed again.

Approve from a real interactive terminal:

```sh
envrun approve
```

The command prints the plan and change summary, then asks for a phrase such as:

```text
approve ruth/app/local
```

Type the exact phrase. Approval cannot be piped and has no `--yes` option.
It also requires the pinned 1Password account configured during setup; `envrun`
does not approve against an implicit desktop default account.

An approval covers the effective environment access set for any later
`envrun run` command under that target and context; it does not approve or hash
a particular command, script, Git commit, or dependency tree. Review project
code before running it.

Approvals become stale when, among other things, a slot reference or bundle
winner changes, passthrough authority changes, the project directory is
replaced, the target working directory changes, the configured account selector
changes, or the trusted `op` binary identity changes. Formatting-only manifest
changes and value rotation within the same 1Password field do not invalidate
approval. Broker code and dependency changes also do not invalidate approval.

List or revoke approvals:

```sh
envrun approvals
envrun revoke
envrun revoke --target worker --context local
envrun revoke --id 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
```

Each `envrun approvals` line begins with its 64-character lowercase hexadecimal
ID. Use `envrun revoke --id ID` to remove an approval without resolving its
manifest, target, or central configuration—for example, after a project was
moved or its configuration became invalid. `--id` cannot be combined with
project-selection options.

## Run a command

Everything after `--` is the target executable and its literal arguments:

```sh
envrun run -- npm test
envrun run -- node server.mjs --port 3000
envrun run --target worker --context local -- ./bin/worker --once
```

`envrun` does not invoke a shell. Spaces, glob characters, backticks, command
substitutions, and semicolons are passed literally. If a shell is genuinely
required, invoke it explicitly and take responsibility for its quoting and
expansion:

```sh
envrun run -- /bin/sh -c 'exec npm run dev'
```

The command runs in the target's configured `cwd`. The target exit code is
propagated, and interrupt/termination signals are forwarded. All descendants of
the target can inherit the selected values unless the target deliberately
removes them before spawning a child.

The broker and target ignore ambient `HOME` and use the current operating-system
user's home directory. They sanitize the caller's `PATH` to unique absolute
entries, falling back to `/usr/local/bin:/usr/bin:/bin` if none remain. Ambient
`XDG_CONFIG_HOME`, `XDG_CACHE_HOME`, `XDG_DATA_HOME`, and `XDG_STATE_HOME` are
not part of the child baseline; `XDG_RUNTIME_DIR` remains available for desktop
IPC such as 1Password integration. The controller can still use
`XDG_CONFIG_HOME` and `XDG_STATE_HOME` to locate `envrun`'s own state before it
constructs the filtered child environment.

`op run` keeps its default output masking enabled, but masking is not a data-loss
prevention boundary. Do not print, encode, write, or transmit secrets.

## Diagnose a project

After setup and from a directory with a discoverable manifest:

```sh
envrun doctor
envrun doctor --json
```

Manifest discovery and complete target/context plan resolution happen before
Doctor's checks start. A malformed manifest, unsafe path, missing slot, invalid
binding, or collision therefore exits as a normal top-level error. In this
preflight failure case, even `doctor --json` does not emit a JSON check report.

After a plan resolves, Doctor reports checks for:

- the Node 24 runtime and `process.execve` support;
- the resolved manifest/target/context selection and binding counts;
- approval status;
- required and optional passthrough declarations;
- refusal of ambient 1Password token authentication;
- the configured 1Password CLI major version;
- configured account selection and ambiguous multiple-account configuration.

Doctor does not resolve project secrets. It exercises desktop authentication by
listing vault metadata, but access to each selected item field and reference
resolution are verified only when `envrun run` starts.

## Common failures

| Message or symptom | Meaning and recovery |
| --- | --- |
| `access is not approved` | Run `envrun plan`, then approve interactively. |
| `access changed` or approval is `stale` | Review the new plan and run `envrun approve` again. |
| `approve requires an interactive controlling terminal` | Run approval directly in a terminal; do not pipe stdin. |
| `token-based 1Password authentication is disabled` | Unset `OP_SERVICE_ACCOUNT_TOKEN`, `OP_CONNECT_TOKEN`, and `OP_SESSION_*`; use desktop app integration. |
| Approval or run requires a pinned account | Run `op account list`, then `envrun setup --update --account ID`. |
| Multiple accounts are configured | Pin one with `envrun setup --update --account ID`. |
| Account authentication fails | Unlock the desktop app, enable CLI integration, and confirm `op vault list` works. |
| The configuration lock helper is unavailable | On Linux restore an executable, trusted `/usr/bin/flock`; on macOS restore `/usr/bin/lockf`. Mutating commands do not proceed unlocked. |
| `required passthrough NAME is not set` | Set it intentionally or move it to `optional_passthrough`. |
| A name is provided by multiple sources | Add a deliberate project override or remove one provider. |
| A name is not listed by the schema | Add it to the schema or the narrow `allow_unlisted` list. |
| One or more slots are not bound | Register every listed slot centrally or correct the corresponding `slot://` IDs. |
| A mode, owner, or symlink check fails | Restore current-user ownership, set central directories to `0700` and files to `0600`, and use real non-symlink paths. |
| The target executable is not found | Use an absolute executable path or ensure it is in an absolute entry of `PATH`. |
| Approval becomes stale after an `op` upgrade | The executable identity changed; review and approve the plan again. |

## Recovery and uninstall

Revoke a project's capability before changing or retiring it:

```sh
envrun revoke
envrun approvals
```

If the project manifest or central configuration cannot be resolved, copy the
64-character ID from `envrun approvals` and run `envrun revoke --id ID`.

If a credential may have been exposed, lock 1Password if appropriate and rotate
the value in 1Password first. Rotation in the same field preserves the slot
reference. If the item or field must change, rebind the slot with `--replace`,
review every now-stale plan, and reapprove only trusted projects.

There is no automated full-reset or uninstall command in v0.1. To remove the
launcher, first inspect it and confirm its second line contains an
`envrun-local-wrapper-v1` or `envrun-release-wrapper-v1` marker, then remove
that one file:

```sh
sed -n '1,2p' ~/.local/bin/envrun
rm ~/.local/bin/envrun
```

The launcher removal leaves configuration and approvals intact. For a
recoverable reset, stop active runs and move these narrow directories to dated
backups instead of deleting them immediately:

```text
$XDG_CONFIG_HOME/envrun       (default: ~/.config/envrun)
$XDG_STATE_HOME/envrun        (default: ~/.local/state/envrun)
```

A release installation also leaves its checksum-named package directory under
`$XDG_DATA_HOME/envrun/releases` (default:
`~/.local/share/envrun/releases`). It contains no project secret values.

The config backup contains reference and account metadata; protect it as private
data. A process killed with `SIGKILL` may leave an `envrun-*` directory in the
system temporary directory. Its `references.env` contains `op://` references,
not values. Inspect ownership and contents before removing only that specific
stale directory.

## Development

Use the pinned npm toolchain from the repository root:

```sh
npm ci
npm run typecheck
npm test
npm run check
```

### Landing page

The Kumo-based landing page lives in `site/` as an isolated React and Vite app,
so its frontend dependencies do not become part of the trusted CLI runtime.
Install and run it from the repository root:

```sh
npm --prefix site ci
npm run site:dev
```

This starts Vite and prints a temporary public `trycloudflare.com` tunnel URL.
Anyone with that URL can access the landing page until `Ctrl+C` stops both the
tunnel and local server. Use `npm --prefix site run dev:local` when a local-only
development server is preferable.

Build the static production output with:

```sh
npm run site:build
```

The default tests cover composition and collision behavior, filesystem boundaries,
interactive approval, ambient-environment filtering, hostile literal arguments,
reference-only snapshots, value rotation, project isolation, concurrent slot
updates, installer behavior, exit/signal propagation, a fake 1Password backend,
and the complete broker/trampoline path with synthetic secrets.

The sibling Ruth and Ezekiel checkouts can also be booted, probed, and stopped
through isolated `envrun` state and the fake backend. Install both applications'
locked dependencies first, ensure ports 3000 and 3001 are free, then run:

```sh
npm run test:accept:real-projects
```

This check refuses plaintext `.env` variants, launches Eve and Deploy separately,
verifies the real HTTP readiness endpoints, then drives each Deploy app through
its complete local provider-stub lifecycle: create an instance, poll it to ready,
verify its event timeline, and delete it. It checks for repo-owned process and
port leaks, restores generated declarations, and requires each Git-visible
worktree to remain byte-for-byte unchanged. An isolated central registry supplies fake references and format-valid
values for every logical slot and bundle selected by the repositories' current
manifests. Value-blind pre-exec assertions prove each exact authorization set
reached the real application process tree, and the provider stubs require the
managed deploy credentials to complete provisioning. The backend audit verifies
all six mode-`0600` manifest-contract snapshots without printing or persistently
caching their resolved values.
Override sibling locations with
`ENVRUN_RUTH_ROOT` and `ENVRUN_EZEKIEL_ROOT` when needed. It does not replace the
live-vault test below.

The live-vault acceptance test is intentionally skipped unless both a configured
account and a dedicated disposable reference are supplied explicitly:

```sh
ENVRUN_TEST_OP_ACCOUNT='my.1password.com' \
ENVRUN_TEST_OP_REFERENCE='op://Test/EnvrunAcceptance/value' \
  npm test
```

The live test resolves the selected field through the installed `/usr/bin/op`,
asserts only that the resulting value is present and no longer an `op://`
reference, and never prints or persists the value. Use a non-production test
field rather than a valuable credential.

## Security

The concise rule is: `envrun` minimizes accidental secret sprawl and makes
environment access reviewable, but it does not make untrusted code safe. The
complete threat model, guarantees, limitations, and incident-response guidance
are in [docs/SECURITY.md](docs/SECURITY.md).
