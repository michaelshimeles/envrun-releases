# envrun security model

This document defines the security boundary of `envrun` v0.1. Read it before
approving a project, choosing passthrough variables, or relying on the tool with
sensitive local-development credentials.

`envrun` is a local dotenv bridge and an advanced consent-based environment
broker. The simple interface can import a plaintext dotenv set into 1Password,
write a reference-only linked file, or explicitly download a plaintext file.
The advanced interface reduces broad ambient inheritance and unnoticed access
changes when launching a process. `envrun` is not a vault, an OS sandbox, an
authorization layer around the entire 1Password account, or a way to make
untrusted code safe.

## Supported use

The supported v1 use case is one human running non-production development code
on a local Linux workstation under one operating-system user account, with
interactive 1Password desktop app authentication. The implementation requires
the Linux `/usr/bin/flock` executable for kernel-backed configuration locking.
A configured 1Password account selector is mandatory for approval and runs.

Version 1 deliberately refuses:

- context names beginning with `prod`;
- `OP_SERVICE_ACCOUNT_TOKEN`;
- `OP_CONNECT_TOKEN`;
- every `OP_SESSION_*` variable.

It is not intended for production, CI, deployment jobs, unattended processes,
shared Unix accounts, hostile multi-user hosts, containers used as a security
boundary, or centrally enforced team policy.

The implementation requires Node.js 24 and currently depends on the
experimental [`process.execve`](https://nodejs.org/docs/latest-v24.x/api/process.html#processexecvefile-args-env)
API. That dependency and the filesystem/terminal behavior make the current
release a workstation-local pilot, not a portable production package.

## Security objectives

Within the supported use case, `envrun` is designed to provide these properties:

1. Managed secret values have one source of truth in 1Password.
2. A default `envrun link` writes references, not values. Plaintext output
   requires the explicit `--download` flag.
3. `envrun store` supplies imported values to `op` over standard input, not
   command arguments, and does not print them.
4. The advanced project manifest contains logical names, not values or full
   1Password references.
5. Beyond the fixed operational baseline, an advanced project run receives only managed names
   and ambient passthrough names included in an explicit, reviewed access set.
6. An advanced run fails closed when that access set lacks approval or changes after
   approval.
7. The advanced run controller does not resolve managed values or intentionally print,
   cache, or persist managed or passthrough values.
8. No implicit shell parses the requested command or its arguments.
9. Ambient credentials outside the approved set are removed before 1Password is
   invoked and filtered again after 1Password resolves values.
10. Value rotation within the same 1Password field works without copying the new
   value to each project.

These objectives primarily address accidental exposure and configuration drift.
They do not defend selected secrets from code after the user chooses to run that
code with an approved environment.

## Trust boundaries

| Component | Trust assumption | Security role |
| --- | --- | --- |
| 1Password desktop app and `op` CLI | Trusted | Stores values, authenticates the user, resolves references, and supervises the target output stream. |
| Release publisher, installed launcher, Node runtime, broker checkout or release directory, build output, and runtime dependencies | Trusted and mutable | Implements and distributes the policy and execution path. These components are not bound into project approvals. |
| Source dotenv passed to `store` | Plaintext secret input | Supplies the complete set that will be stored. It remains unchanged after a successful import. |
| Linked dotenv output | Private project metadata by default | Contains names and full `op://` references. With `--download`, it instead contains plaintext values. |
| Tagged 1Password project item | Trusted source of truth | Stores one project's complete environment set as concealed fields. |
| Linux kernel and `/usr/bin/flock` | Trusted | Provide advisory serialization for central configuration mutations. |
| Central `envrun` config | Trusted current-user metadata | Maps logical slots to references and defines reusable bundles. |
| Project `.dev-env.toml` | Untrusted until reviewed | Requests logical bundles, bindings, overrides, and passthrough authority. It cannot contain values, but it can request access. |
| `.env.example` schema | Project-controlled allowlist | Limits which names may be authorized; it does not require or inject every listed name. |
| Approval state | Trusted current-user consent record | Binds a project/target/context to one effective access set and configured 1Password backend identity. |
| Target command and descendants | Trusted with every selected value | May read, transform, persist, log, or transmit all values they receive. |
| Other processes running as the same UID | Outside the protection boundary | May be able to inspect files/processes or invoke 1Password independently. |

The project manifest is safe to commit in the narrow sense that it contains
logical `slot://` identifiers rather than values. A manifest change can still be
security-sensitive because it can request a new slot or passthrough name.
The schema parser ignores assignment right-hand sides; it does not remove a
plaintext value someone has already put in `.env.example`. Keep schema values
empty or synthetic and review that file before committing it.

The local installer writes a wrapper that imports mutable `dist/cli.js` and
runtime dependencies from the checkout. It verifies the checkout, built CLI,
Node executable, and launcher directory ownership/modes; world-writable paths
are refused, and group-writable paths are accepted only for the current user's
primary group. Keep that group private and treat the recorded Node executable
path as trusted. Review and rebuild broker/dependency updates; changing this
code or its dependencies does not stale an existing project approval.

The public installer downloads an immutable, versioned archive, a SHA-256
manifest for every release asset, and an Ed25519 signature over that manifest.
It verifies the signature against the embedded envrun release key before parsing the manifest or
extracting the archive. It then rejects unsafe archive paths and file types and
verifies an internal SHA-256 manifest before and after placing the release under
the current user's XDG data directory. Release directories are named with both
the version and archive digest. A managed release may replace only a launcher
containing a recognized release-wrapper marker; it does not overwrite a
local-checkout wrapper or an unrelated executable.

The release-signing private key is stored separately from the public download
repository as an encrypted private-source workflow secret. A verifier loaded
only from the public repository's protected default branch refuses an invalid
signature or an asset absent from the signed manifest before creating a draft.
Publishing the draft activates GitHub release immutability, which locks the
assets and tag and creates a GitHub release attestation. The release also
contains an SPDX 2.3 bill of materials for the shipped dependency set.
Repository rules reject tag deletion and updates. A compromised public deploy
key alone therefore cannot forge a valid archive or replace a published one.

The private tagged-build workflow, locked dependencies, signing key, public
verification workflow, GitHub, OpenSSH implementation, and HTTPS certificate
authorities remain trusted supply-chain components. Piping even a signed-release
installer directly to a shell trusts that installer before its embedded key can
perform verification. Prefer a pinned release URL, compare the documented key
fingerprint, and inspect the installer when stronger bootstrap assurance is
needed. Installed release code remains mutable by the same operating-system
user, and upgrading it does not stale project approvals.

## Data classification and storage

### Secret values

`envrun store` intentionally reads values from the source dotenv file into
memory and sends a JSON item template to `op item create` or `op item edit` over
standard input. It does not remove or rewrite that source file. It does not put
values in process arguments, terminal output, envrun configuration, or logs.

`envrun link` retrieves only item and field metadata and writes an atomic
mode-`0600` reference file. `envrun link --download` intentionally asks
`op item get --reveal` for the values and writes them atomically to the requested
path at mode `0600`. That file is persistent plaintext, outside envrun's ongoing
control, and must be excluded from version control and removed by the user when
no longer needed. Both link modes replace the exact path named by the user and
refuse symlinked inputs, outputs, or parent path components.

For the advanced broker workflow, managed values are expected to exist in
1Password and, during a run, in process memory and environment blocks. Explicit
passthrough values originate in the caller's ambient environment and may
themselves be sensitive. Neither category is intentionally stored by the
advanced run path in configuration, approval files, temporary plaintext files,
logs, or command arguments.

The advanced outer controller process does not receive resolved values. A separate
`envrun` trampoline launched beneath `op run` necessarily receives them in its
environment, reads the selected names, constructs the final filtered
environment, and then replaces itself with the target using `execve`. This is
transient plaintext handling in memory; “no plaintext files” does not mean that
no process ever holds plaintext.

### 1Password references

Full `op://` references are metadata, not secret values, but can reveal vault,
item, section, or field names. They are stored in the central slot registry and
in a short-lived references-only environment file for advanced `op run` calls.
The simple `link` command also stores full references persistently in the exact
dotenv path selected by the user; that file is mode `0600` and should remain
uncommitted.

Reference files are created in a dedicated mode-`0700` temporary directory with
a mode-`0600` file. Normal completion removes the directory. `SIGKILL`, power
loss, kernel failure, or a process crash can prevent cleanup; a stale file still
contains references rather than values and should be treated as private
metadata.

References are validated as static
`op://VAULT/ITEM/[SECTION/]FIELD` paths. Control bytes and `$` interpolation are
rejected, preventing a project from parameterizing a reference through ambient
state.

### Logical metadata and approvals

Global bundles and project manifests store `slot://` IDs. Human plans display
logical IDs and truncated reference digests, not full references. Approval
records contain full reference digests and logical source information, not
values or references.

By default:

```text
~/.config/envrun/                 mode 0700
  settings.toml                  mode 0600
  slots.toml                     mode 0600
  .*.lock                        mode 0600
  bundles/...                    directories 0700, files 0600

~/.local/state/envrun/           mode 0700
  approvals/...                  files 0600
```

The corresponding absolute XDG locations are used when `XDG_CONFIG_HOME` or
`XDG_STATE_HOME` is set. Dot segments and null bytes are rejected. Central
directories and files must be owned by the current user; directories must be
mode `0700` and files mode `0600`. Every existing XDG/configuration path
component is checked and symlinks are refused. The final manifest file must be
a regular non-symlink file, and explicit `--manifest` paths also reject symlinked
parent components. Schema and target working-directory paths must remain inside
the canonical project root and may not traverse symlinks.

## Execution sequence

A successful run follows this sequence:

1. Load and strictly validate the project manifest, target, context, schema,
   central settings, slots, and selected bundles.
2. Build all candidate bindings. Reject missing slots, undeclared names, stale
   overrides, reserved names, and collisions without an explicit override.
3. Calculate a fingerprint for the effective authorization set and compare it
   with the stored approval.
4. Recheck the trusted `op` executable and mandatory pinned account selector
   before execution.
5. Build an immutable, references-only snapshot for the selected managed names.
6. Construct a backend environment from a small operational baseline plus only
   explicit required and currently present optional passthrough variables.
7. Start the pinned 1Password CLI as `op run --env-file=<snapshot> -- ...` with
   no shell and without `--no-masking`.
8. Let `op run` resolve references into the child trampoline's environment.
9. In the trampoline, reconstruct the environment from the operational baseline
   and the exact approved contract. Drop unrelated ambient variables and all
   1Password authentication variables.
10. Resolve the target executable without a shell and replace the trampoline
    using `process.execve`.
11. Propagate the target's exit result and remove the references snapshot on the
    normal cleanup path.

The snapshot makes an in-flight run deterministic: a concurrent central slot
change does not switch the reference halfway through that run. A subsequent
plan sees the new reference and marks the approval stale.

An override chooses one source that is already present in the candidate set. A
bundle source is named `bundle:ID`; the context's project-binding source is
named `project:PROJECT/TARGET/CONTEXT`. It cannot use a `slot://` mapping or
introduce a new candidate. Candidate multiplicity—not reference equality—defines
a collision, so even two sources resolving to the same reference require an
explicit selector. A selector is rejected if it is absent during a collision,
names a noncandidate, or remains after the collision disappears.

## Approval semantics

`envrun run` never creates approval. `envrun approve` requires a pinned
1Password account selector and a controlling terminal, prints the effective
plan and changes, and requires an exact phrase. Piped input and a non-interactive
`--yes` approval path are intentionally absent. Runs also refuse an unpinned
account, including if an older approval record exists.

Approval is bound to security-relevant inputs including:

- canonical project root path, filesystem device, and inode;
- project ID, target, and context;
- target working directory and schema path;
- every managed name, candidate source, winning slot, and reference digest;
- required and optional passthrough declarations;
- configured 1Password account selector;
- canonical `op` path and executable device, inode, size, and modification time.

Consequences:

- Rebinding a slot, changing a bundle winner, adding passthrough authority,
  replacing the project directory, changing the configured account selector,
  or updating the trusted `op` binary requires review and reapproval.
- Rotating a value inside the same 1Password field leaves the static reference
  unchanged and keeps approval valid.
- Formatting-only manifest edits remain valid if the effective access set is
  unchanged.
- Adding an unbound name to the schema does not grant access, because the schema
  is only an allowlist.

An approval is **not** bound to a target command, file contents, Git remote,
commit, branch, package-lock contents, dependency graph, build artifact, broker
code, Node runtime, or broker dependencies. It authorizes the selected
environment set for any command the user later supplies for that
project/target/context. Project or broker code can change in place without
invalidating approval. Review code and dependencies before every
security-sensitive run.

## Environment filtering

The backend and target receive a small operational baseline needed to launch a
normal local process. Ambient `HOME` is ignored; `HOME` is derived from the
operating-system account via `userInfo().homedir`. The caller's `PATH` is
filtered to unique absolute entries, with `/usr/local/bin:/usr/bin:/bin` used if
none remain. The same sanitized `PATH` is used to find the initial target and is
then inherited by it. These are trusted operational inputs, not approved
project-controlled bindings.

The inherited baseline is limited to conventional user identity, shell,
locale (`LANG`, `LANGUAGE`, `TZ`, and `LC_*`), terminal, temporary-directory,
display/session, color, and CI variables. `XDG_RUNTIME_DIR` remains in the
baseline because desktop IPC may require it. Ambient `XDG_CONFIG_HOME`,
`XDG_CACHE_HOME`, `XDG_DATA_HOME`, and `XDG_STATE_HOME` are not inherited
automatically. The controller may use config/state locations to find its own
files before filtering, and a nonreserved XDG name can enter the child only if
the manifest explicitly authorizes it as passthrough. The target's `PWD` is set
to its resolved configured working directory.

Everything else is dropped unless it is explicitly declared as managed,
required passthrough, or optional passthrough. In particular, the broker does
not automatically inherit variables merely because their names appear in
`.env.example`.

Required passthrough names must be present. Optional passthrough names are
included only when set, but the authority to include them is part of the
approved plan. Values containing an undeclared `op://` reference are refused so
the backend cannot discover additional references through ambient variables.

Execution-control and authentication-sensitive names are reserved. The
reserved set includes `PATH`, `HOME`, language/runtime injection hooks such as
`NODE_OPTIONS` and `PYTHONPATH`, dynamic-loader prefixes such as `LD_` and
`DYLD_`, Git configuration injection names, every `OP_` name, and every
`ENVRUN_` name. Some reserved baseline names are supplied by `envrun` itself but
cannot be replaced by a project binding or passthrough declaration.

Filtering is not sandboxing. Although `HOME` is derived rather than inherited,
it still points to the current user's real home. The baseline also includes the
sanitized `PATH`, display/session information, and other ordinary local-process
state. The target runs as the current user and retains that user's filesystem,
network, IPC, and device permissions.

## 1Password authentication boundary

Version 1 uses 1Password desktop app integration. The configured `op` binary is
resolved to an absolute path, must be a regular executable owned by root or the
current user, and may not be group- or world-writable. Approval and execution
require a configured account, which is passed with `--account`; `OP_ACCOUNT`
and other ambient `OP_*` variables are not trusted as selectors.

Token-based authentication is refused so a long-lived service-account, Connect,
or session token cannot accidentally flow into the target. Configure app
integration persistently in the 1Password desktop application rather than
depending on an ambient `OP_*` toggle.

This design has an important limitation: desktop app integration may authorize
the user's broader 1Password account. `envrun` approval limits which references
the broker places in the target environment; it does not create a narrower
1Password ACL. Code running as the same user can attempt to execute `op` itself,
and 1Password—not `envrun`—decides whether to authorize that request.

If the threat model requires a technically enforced vault-level boundary around
malicious code, v0.1 is the wrong tool. Use separately scoped credentials plus
an OS/container/VM sandbox designed for hostile code. Although 1Password service
accounts can provide vault scoping, they are deliberately unsupported by this
interactive desktop-only version.

## No-shell guarantee

`envrun` passes the target executable and arguments as an argument vector. It
does not use `eval`, `execSync`, `shell: true`, `op read`, or `op inject`.
Characters such as spaces, `*`, semicolons, backticks, dollar signs, and newlines
in target arguments do not gain shell meaning.

Users can explicitly run `/bin/sh -c ...`; doing so creates a shell boundary
outside this guarantee. Shell expansion, quoting, startup files, and commands in
that string become the user's responsibility.

## Process-tree exposure

Environment variables are a delivery mechanism, not a secret enclave. The
target can read every selected value, and its children normally inherit them.
Any selected process can:

- print a value or a derivative;
- write it to source files, logs, caches, swap, or crash dumps;
- transmit it over the network or local IPC;
- expose it to debuggers, tracing tools, plugins, build hooks, test reporters,
  package scripts, or child processes;
- keep using it for the lifetime permitted by the upstream service.

Other same-UID processes may be able to inspect process environments or memory,
depending on the operating system's `/proc`, ptrace, debugger, and core-dump
policy. `envrun` does not change those policies.

Minimize the number and scope of values in each target. Prefer short-lived,
development-only credentials with provider-side permissions restricted to the
smallest useful resource set. Have the target clear values before spawning
children that do not need them.

## Output masking is not DLP

`envrun` leaves 1Password CLI's default output masking enabled. This can reduce
accidental printing of values recognized by `op run`, but it is not a security
boundary and must not be treated as data-loss prevention.

Masking cannot reliably prevent exposure through encoding, slicing,
transformation, structured output, files, network traffic, a different file
descriptor, debugger access, or a process that bypasses the supervised output
path. A target that is allowed to read a value is capable of exfiltrating it.

## Same-UID and local filesystem limitations

The no-group/world-permission directory checks and mode-`0600` file checks
protect against ordinary access by other Unix users and catch accidental
permission regressions. They do not protect against root, a compromised kernel,
malware already running as the same user, or a same-UID process with sufficient
debugging/filesystem rights.

A same-UID process may be able to:

- read central `op://` references;
- read persistent linked references or a plaintext file created with `--download`;
- read the source dotenv file before or after `envrun store` imports it;
- read a references-only temporary snapshot while a run is active;
- modify project code or manifest files before the user runs them;
- invoke the installed `op` CLI independently;
- inspect or influence target processes through normal same-user mechanisms.

Do not use a shared Unix account as an isolation boundary. Put truly untrusted
projects in a separate user, VM, or other security boundary and do not grant
that boundary personal 1Password desktop access.

## Ruth and Ezekiel isolation example

The example configuration in the README gives both projects the shared
`providers/openai/default` slot while binding `DATABASE_URL` to separate
`projects/ruth/database` and `projects/ezekiel/database` slots.

The broker guarantees that its resolved Ruth plan does not silently include the
Ezekiel database binding, and vice versa. Each canonical project root and target
has independent approval. A binding collision fails unless the manifest names
an exact existing candidate source as its override.

Logical ID prefixes are not an ACL. A modified Ruth manifest can request
`slot://projects/ezekiel/database`; the protection is that this request appears
in the effective plan and invalidates Ruth's approval. A user who approves it has
authorized that cross-project environment access.

This is configuration-level isolation. Once Ruth's code is run, it is trusted
with Ruth's database value and the shared OpenAI value. It is not prevented from
reading local files, using the network, or asking the desktop-authenticated
1Password CLI for something else.

## Fail-closed behavior and failure modes

Before starting 1Password, `envrun` refuses malformed or unknown TOML fields,
unsafe paths, symlinks, permissive central files, missing slots, collisions,
stale overrides, production contexts, reserved names, token authentication,
missing required passthrough values, missing approval, and stale approval.

Once execution starts:

- 1Password authentication or reference failures are returned by `op run`;
- a managed value still shaped like an unresolved `op://` reference is refused;
- a missing target executable returns a command-not-found-style failure;
- target exit codes and common termination signals are propagated;
- cleanup of references metadata is best effort on abnormal termination.

Central configuration writes are atomic. Setup, slot, and bundle mutations are
serialized with Linux `/usr/bin/flock` over current-user-owned mode-`0600` lock
files. The kernel releases an advisory lock when its helper exits or crashes;
the harmless lock file can remain. Updates wait for up to the configured
internal timeout and fail rather than proceeding unlocked. No filesystem
protocol can make the state safe against a malicious same-UID process
deliberately racing or replacing files; that actor is outside the threat model.

## Operational recommendations

Before approval:

1. Review `.dev-env.toml`, especially bundles, bindings, overrides,
   `allow_unlisted`, `passthrough`, and `optional_passthrough`.
2. Run `envrun plan` and use `envrun plan --json` when its machine-readable
   backend summary and short executable-identity digest are useful.
3. Confirm the canonical project root and target working directory.
4. Review the project code, package scripts, dependencies, and command you plan
   to run.
5. Use development-only upstream credentials with narrowly scoped provider
   permissions.

During operation:

- keep the 1Password desktop app and CLI updated;
- pin the 1Password account selector; expect a configured selector change or an
  `op` binary update to require reapproval;
- do not add broad ambient credentials to passthrough for convenience;
- avoid printing environments in debug output;
- avoid shells and package lifecycle scripts you have not reviewed;
- revoke targets that are no longer in use.

After operation:

- rotate credentials on the provider's schedule or after suspected exposure;
- inspect 1Password's desktop CLI activity log when investigating unexpected
  access;
- remove stale project approvals and unused slot/bundle mappings;
- inspect any crash artifacts or stale temporary reference directories before
  disposing of them.

## Incident response

If a value may have been exposed:

1. Stop the target and its descendants.
2. Lock 1Password if ongoing local misuse is suspected.
3. Revoke or rotate the credential at the upstream provider and update its
   1Password field.
4. Run `envrun revoke` for affected project targets. If planning is impossible
   because the manifest or configuration is broken, obtain the 64-character ID
   from `envrun approvals` and run `envrun revoke --id ID` without resolving the
   project plan.
5. If the item or field reference changes, rebind the logical slot with
   `--replace`; do not approve the resulting stale plans until reviewed.
6. Inspect source trees, logs, caches, shell history, build output, temporary
   files, crash dumps, network logs, and 1Password CLI activity as appropriate.
7. Assume every descendant of the approved target could have received the
   value.

Do not include live values, full references, approval files, or account details
in a bug report. Reproduce security defects with synthetic vault, item, field,
and secret data.
