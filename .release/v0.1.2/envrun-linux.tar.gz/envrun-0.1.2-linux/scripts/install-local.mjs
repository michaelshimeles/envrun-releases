import {
  chmod,
  lstat,
  mkdir,
  open,
  readdir,
  readFile,
  readlink,
  rename,
} from "node:fs/promises";
import {
  basename,
  dirname,
  isAbsolute,
  join,
  parse as parsePath,
  relative,
  resolve,
  sep,
} from "node:path";
import { userInfo } from "node:os";
import { fileURLToPath, pathToFileURL } from "node:url";
import { randomBytes } from "node:crypto";
import { createHash } from "node:crypto";

function terminalSafe(value) {
  return JSON.stringify(String(value)).slice(1, -1).replace(
    /[\u007f-\u009f\u2028\u2029\u202a-\u202e\u2066-\u2069]/gu,
    (character) =>
      `\\u${(character.codePointAt(0) ?? 0).toString(16).padStart(4, "0")}`,
  );
}

async function main() {
  const repository = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  const distDirectory = join(repository, "dist");
  const target = join(distDirectory, "cli.js");
  const currentUser = userInfo();
  const currentUid =
    typeof process.getuid === "function" ? process.getuid() : undefined;
  const assertTrusted = (info, label, kind, allowStickyAncestor = false) => {
    if (info.isSymbolicLink()) {
      throw new Error(`${label} may not be a symlink`);
    }
    if (kind === "directory" ? !info.isDirectory() : !info.isFile()) {
      throw new Error(`${label} must be a real ${kind}`);
    }
    if (currentUid !== undefined && info.uid !== currentUid && info.uid !== 0) {
      throw new Error(`${label} must be owned by the current user or root`);
    }
    const protectedStickyAncestor =
      allowStickyAncestor &&
      info.isDirectory() &&
      info.uid === 0 &&
      (info.mode & 0o1000) !== 0;
    if ((info.mode & 0o002) !== 0 && !protectedStickyAncestor) {
      throw new Error(`${label} must not be world-writable`);
    }
    const privatePrimaryGroup =
      currentUid !== undefined &&
      info.uid === currentUid &&
      info.gid === currentUser.gid;
    if (
      (info.mode & 0o020) !== 0 &&
      !privatePrimaryGroup &&
      !protectedStickyAncestor
    ) {
      throw new Error(
        `${label} may be group-writable only when owned by the current user's primary group`,
      );
    }
  };
  const assertTrustedPath = async (
    path,
    label,
    leafKind,
    allowMissing = false,
  ) => {
    const absolute = resolve(path);
    const root = parsePath(absolute).root;
    const components = absolute.slice(root.length).split(sep).filter(Boolean);
    let cursor = root;
    const paths = [root];
    for (const component of components) {
      cursor = join(cursor, component);
      paths.push(cursor);
    }
    for (const [index, componentPath] of paths.entries()) {
      const isLeaf = index === paths.length - 1;
      let info;
      try {
        info = await lstat(componentPath);
      } catch (error) {
        if (allowMissing && error?.code === "ENOENT") return;
        throw error;
      }
      assertTrusted(
        info,
        isLeaf ? label : `${label} ancestor ${componentPath}`,
        isLeaf ? leafKind : "directory",
        !isLeaf,
      );
    }
  };
  const assertTrustedTree = async (treeRoot, label, current = treeRoot) => {
    const info = await lstat(current);
    const entryLabel =
      current === treeRoot ? label : `${label} entry ${relative(treeRoot, current)}`;
    if (info.isSymbolicLink()) {
      throw new Error(`${entryLabel} may not be a symlink`);
    }
    if (!info.isDirectory() && !info.isFile()) {
      throw new Error(`${entryLabel} must be a real file or directory`);
    }
    assertTrusted(info, entryLabel, info.isDirectory() ? "directory" : "file");
    if (!info.isDirectory()) return;
    for (const name of await readdir(current)) {
      await assertTrustedTree(treeRoot, label, join(current, name));
    }
  };
  const readPackage = async (packageFile, label) => {
    await assertTrustedPath(packageFile, `${label} package metadata`, "file");
    let value;
    try {
      value = JSON.parse(await readFile(packageFile, "utf8"));
    } catch (error) {
      throw new Error(`${label} package metadata is not valid JSON: ${error.message}`);
    }
    if (value === null || typeof value !== "object" || Array.isArray(value)) {
      throw new Error(`${label} package metadata must be an object`);
    }
    return value;
  };
  const packageNameParts = (name) => {
    if (typeof name !== "string") return undefined;
    const parts = name.split("/");
    if (
      (parts.length !== 1 && !(parts.length === 2 && parts[0].startsWith("@"))) ||
      parts.some((part) => part === "" || part === "." || part === ".." || part.includes("\\"))
    ) {
      return undefined;
    }
    return parts;
  };
  const dependencyRequests = (manifest, label) => {
    const requests = new Map();
    const add = (field, optional) => {
      const dependencies = manifest[field];
      if (dependencies === undefined) return;
      if (
        dependencies === null ||
        typeof dependencies !== "object" ||
        Array.isArray(dependencies)
      ) {
        throw new Error(`${label} ${field} must be an object`);
      }
      for (const name of Object.keys(dependencies)) {
        if (!packageNameParts(name)) {
          throw new Error(`${label} contains invalid dependency name ${name}`);
        }
        requests.set(name, optional);
      }
    };
    add("dependencies", false);
    add("optionalDependencies", true);
    const peers = manifest.peerDependencies;
    if (peers !== undefined) {
      if (peers === null || typeof peers !== "object" || Array.isArray(peers)) {
        throw new Error(`${label} peerDependencies must be an object`);
      }
      for (const name of Object.keys(peers)) {
        if (!packageNameParts(name)) {
          throw new Error(`${label} contains invalid dependency name ${name}`);
        }
        const optional = manifest.peerDependenciesMeta?.[name]?.optional === true;
        if (!requests.has(name)) requests.set(name, optional);
      }
    }
    return [...requests].map(([name, optional]) => ({ name, optional }));
  };
  const findInstalledDependency = async (importer, name) => {
    const parts = packageNameParts(name);
    if (!parts) throw new Error(`invalid runtime dependency name ${name}`);
    let cursor = importer;
    while (true) {
      // Node skips a redundant node_modules/node_modules lookup while walking up.
      if (basename(cursor) !== "node_modules") {
        const candidate = join(cursor, "node_modules", ...parts);
        const withinRepository = relative(repository, candidate);
        if (
          withinRepository !== ".." &&
          !withinRepository.startsWith(`..${sep}`) &&
          !isAbsolute(withinRepository)
        ) {
          try {
            await lstat(candidate);
            return candidate;
          } catch (error) {
            if (error?.code !== "ENOENT") throw error;
          }
        }
      }
      if (cursor === repository) return undefined;
      const parent = dirname(cursor);
      if (parent === cursor) return undefined;
      cursor = parent;
      const fromRepository = relative(repository, cursor);
      if (fromRepository === ".." || fromRepository.startsWith(`..${sep}`)) {
        return undefined;
      }
    }
  };
  const assertRuntimeDependencies = async (manifest) => {
    const pending = dependencyRequests(manifest, "envrun package").map((request) => ({
      ...request,
      importer: repository,
    }));
    const validated = new Set();
    while (pending.length > 0) {
      const request = pending.shift();
      const packageRoot = await findInstalledDependency(request.importer, request.name);
      if (packageRoot === undefined) {
        if (request.optional) continue;
        throw new Error(`runtime dependency ${request.name} is not installed in this checkout`);
      }
      await assertTrustedPath(
        packageRoot,
        `runtime dependency ${request.name}`,
        "directory",
      );
      if (validated.has(packageRoot)) continue;
      await assertTrustedTree(packageRoot, `runtime dependency ${request.name}`);
      const dependencyManifest = await readPackage(
        join(packageRoot, "package.json"),
        `runtime dependency ${request.name}`,
      );
      validated.add(packageRoot);
      for (const dependency of dependencyRequests(
        dependencyManifest,
        `runtime dependency ${request.name}`,
      )) {
        pending.push({ ...dependency, importer: packageRoot });
      }
    }
  };

  await assertTrustedPath(repository, "envrun checkout", "directory");
  const manifest = await readPackage(join(repository, "package.json"), "envrun");
  await assertTrustedPath(distDirectory, "envrun dist directory", "directory");
  await assertTrustedTree(distDirectory, "envrun dist");
  await assertTrustedPath(target, "built envrun CLI", "file");
  await assertRuntimeDependencies(manifest);

  const args = process.argv.slice(2);
  let binDirectory = join(currentUser.homedir, ".local", "bin");
  let releaseVersion;
  for (let index = 0; index < args.length; index += 1) {
    const option = args[index];
    const value = args[index + 1];
    if (option === "--bin-dir" && value !== undefined && isAbsolute(value)) {
      binDirectory = resolve(value);
      index += 1;
      continue;
    }
    if (
      option === "--release" &&
      value !== undefined &&
      /^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$/.test(value)
    ) {
      releaseVersion = value;
      index += 1;
      continue;
    }
    throw new Error(
      "usage: install-local.mjs [--bin-dir /absolute/path] [--release VERSION]",
    );
  }
  if (releaseVersion !== undefined) {
    const packagedVersion = (await readFile(join(repository, "VERSION"), "utf8")).trim();
    if (packagedVersion !== releaseVersion) {
      throw new Error("release version does not match the packaged VERSION file");
    }
  }
  const destination = join(binDirectory, "envrun");
  if (!process.execPath.startsWith("/") || /[\r\n]/.test(process.execPath)) {
    throw new Error("envrun local installation requires an absolute Node executable path");
  }
  if (Number(process.versions.node.split(".")[0]) !== 24) {
    throw new Error("envrun local installation requires Node 24");
  }
  await assertTrustedPath(process.execPath, "Node executable", "file");
  const nodeInfo = await lstat(process.execPath);
  if ((nodeInfo.mode & 0o111) === 0) {
    throw new Error("Node executable is not executable");
  }
  const repositoryDigest = createHash("sha256")
    .update(repository)
    .digest("hex")
    .slice(0, 16);
  const marker =
    releaseVersion === undefined
      ? `// envrun-local-wrapper-v1:${repositoryDigest}`
      : `// envrun-release-wrapper-v1:${releaseVersion}:${repositoryDigest}`;
  const wrapper = `#!${process.execPath}\n${marker}\nawait import(${JSON.stringify(pathToFileURL(target).href)});\n`;

  await assertTrustedPath(binDirectory, "envrun bin directory", "directory", true);
  await mkdir(binDirectory, { recursive: true, mode: 0o700 });
  await assertTrustedPath(binDirectory, "envrun bin directory", "directory");
  try {
    const info = await lstat(destination);
    if (info.isSymbolicLink()) {
      const existing = resolve(dirname(destination), await readlink(destination));
      if (existing !== target) {
        throw new Error(`${destination} points somewhere else: ${existing}`);
      }
    } else if (info.isFile()) {
      const existing = await readFile(destination, "utf8");
      const existingMarker = existing.split(/\r?\n/, 3)[1] ?? "";
      const isManagedRelease =
        /^\/\/ envrun-release-wrapper-v1:[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?:[0-9a-f]{16}$/.test(
          existingMarker,
        );
      if (
        releaseVersion === undefined
          ? existingMarker !== marker
          : !isManagedRelease
      ) {
        throw new Error(`${destination} already exists and is not this envrun wrapper`);
      }
    } else {
      throw new Error(`${destination} already exists and is unsupported`);
    }
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }

  const temporary = join(
    binDirectory,
    `.envrun-${randomBytes(8).toString("hex")}.tmp`,
  );
  const handle = await open(temporary, "wx", 0o755);
  try {
    await handle.writeFile(wrapper, "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await chmod(temporary, 0o755);
  await rename(temporary, destination);
  console.log(`installed durable wrapper: ${terminalSafe(destination)}`);
}

try {
  await main();
} catch (error) {
  const detail = error instanceof Error ? error.message : "unexpected installation failure";
  process.stderr.write(`envrun installer: ${terminalSafe(detail)}\n`);
  process.exitCode = 1;
}
